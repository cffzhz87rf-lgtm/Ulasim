# Ulaşım İmparatorluğu — Aşama 1, sürüm 0.1

React + TypeScript + Vite tabanlı, **tarayıcıda oynanabilir erken prototip**. Unity projesi değildir. Öncelik mobil yatay ekran.

## Çalıştırma

Node.js 20+ kurulu bilgisayarda:

```bash
npm install
npm run dev
```

Terminalde gösterilen yerel adresi tarayıcıda açın. Aynı ağdaki telefondan bilgisayarın IP adresi ve Vite portuyla açabilirsiniz. Üretim derlemesi için `npm run build`.

## Gerçekten eklenenler

- İşsiz başlangıç, iş başvurusu, muavin vardiyası ve ücret kazanma
- Üç vardiyadan sonra oyun içi şoförlük eğitimi
- 18.000 ₺'ye temsili ikinci el minibüs alımı
- Burç → Çamardı seferi, yolcu geliri, yakıt/bakım, oyun içi dakika ilerletme
- Aynı anda tek aktif sefer; tamamlanmış sefere ikinci kez gelir yazılmaması
- Koyu lacivert/altın, yatay ekran için tasarlanmış yönetim arayüzü
- Tarayıcı localStorage kaydı, JSON yedek dışa/içe aktarma
- Sınırlı örnek il/ilçe seçimi

## Eksikler / bilinçli sınırlamalar

- 81 ilin ve tüm ilçelerin doğrulanmış veri seti, köyler ve gerçek harita henüz yoktur. İl/ilçe seçimi örnek 7 il ile sınırlıdır. Burç–Çamardı rota şeması gerçek koordinat/mesafe değildir.
- Gerçekçi araç/terminal fotoğrafları ve 3D sahneler yok; yerel çizim ve ikonlar geçici görsellerdir.
- Gerçek arka plan zaman takibi, reklam, bulut kayıt, ödeme ve uygulama paketleme yok.
- İngilizce dil seçimi altyapı yer tutucusudur; çeviri yapılmadı.
- Mesleki yeterlilik, ruhsat ve ekonomi değerleri gerçek dünya koşullarını temsil etmez; oyun içi basitleştirmelerdir.
- İş görüşmesi şimdilik tek tıklamalı, görevler başlangıç prototipi düzeyindedir.
- Kod ve gerçek cihaz testleri, kurulum/derleme ortamında ayrıca doğrulanmalıdır.

## Kayıt güvenliği

Ayarlar menüsünden JSON yedek alın. Tarayıcı site verileri silinirse localStorage kaydı kaybolabilir.

## v0.2 — Gerçek Türkiye haritası (yeni)

Harita sekmesindeki önceki sahte çizim kaldırıldı. Gerçek il ve ilçe sınırları **geoBoundaries gbOpen Türkiye ADM1/ADM2** GeoJSON API'sinden alınır. 81 il ve mevcut veri kümesindeki tüm ilçe sınırları tek seferde yüklenir; il seçildiğinde o ilin içindeki ilçe poligonları coğrafi olarak eşleştirilir. Bir il veya ilçeye dokunarak oyun konumu seçilir. İnternet veya veri kaynağı çalışmazsa açık hata gösterilir; uydurma harita gösterilmez.

Kaynak: https://www.geoboundaries.org/ · API: https://www.geoboundaries.org/api/current/gbOpen/TUR/ADM1/ ve /ADM2/ · gbOpen lisansı CC BY 4.0; harita atfı korunmalıdır. Kaynak veri yayın yılı ve güncelliği ayrıca doğrulanmalıdır. Yerleşim (köy/mahalle) ve gerçek yol rotaları bu aşamada yoktur. Otobüsün haritada gösterimi yalnızca örnek konumdur, gerçek yol animasyonu değildir.

**Önemli:** API canlı erişim gerektirir. Bu çalışma ortamında internet erişimi olmadığından uzaktaki veri indirilemedi ve npm bağımlılıkları kurulup derleme testi yapılamadı. Harita entegrasyonu gerçek bir tarayıcıda test edilmelidir. Daha sağlam üretim sürümü için GeoJSON dosyalarını lisanslarıyla birlikte projeye indirip statik dosya olarak barındırın.
