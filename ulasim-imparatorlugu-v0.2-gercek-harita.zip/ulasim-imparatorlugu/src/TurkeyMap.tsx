import React, {useEffect,useMemo,useState} from 'react';
import {MapPinned, RefreshCw, BusFront} from 'lucide-react';
import type {Game} from './engine';
import './turkey-map.css';

type Position=[number,number];
type Polygon={type:'Polygon';coordinates:Position[][]};
type MultiPolygon={type:'MultiPolygon';coordinates:Position[][][]};
type Feature={type:'Feature';properties:{shapeName?:string;name?:string};geometry:Polygon|MultiPolygon};
type Collection={type:'FeatureCollection';features:Feature[]};
type Level='ADM1'|'ADM2';
const ENDPOINT='https://www.geoboundaries.org/api/current/gbOpen/TUR/';
const cache=new Map<Level,Collection>();
async function getLevel(level:Level):Promise<Collection>{
  const cached=cache.get(level);if(cached)return cached;
  const metaResponse=await fetch(`${ENDPOINT}${level}/`);
  if(!metaResponse.ok)throw Error(`geoBoundaries ${level}: HTTP ${metaResponse.status}`);
  const metadata=await metaResponse.json();
  if(typeof metadata.gjDownloadURL!=='string')throw Error('Coğrafi veri bağlantısı bulunamadı');
  const geoResponse=await fetch(metadata.gjDownloadURL);
  if(!geoResponse.ok)throw Error(`GeoJSON: HTTP ${geoResponse.status}`);
  const json=await geoResponse.json();
  if(json.type!=='FeatureCollection'||!Array.isArray(json.features))throw Error('Geçersiz GeoJSON');
  cache.set(level,json);return json;
}
// Fixed geographic projection: actual coordinates, not a hand-drawn Turkey silhouette.
const W=1000,H=440;
function project([lon,lat]:Position):Position{return [(lon-25.5)/(45.2-25.5)*W,(42.5-lat)/(42.5-35.4)*H]}
function rings(geo:Polygon|MultiPolygon):Position[][][]{return geo.type==='Polygon'?[geo.coordinates]:geo.coordinates}
function path(geo:Polygon|MultiPolygon):string{return rings(geo).map(poly=>poly.map(r=>r.map((p,i)=>{const [x,y]=project(p);return `${i?'L':'M'}${x.toFixed(1)},${y.toFixed(1)}`}).join(' ')+'Z').join(' ')).join(' ')}
function insideRing(p:Position,ring:Position[]):boolean{let yes=false;for(let i=0,j=ring.length-1;i<ring.length;j=i++){const a=ring[i],b=ring[j];if(((a[1]>p[1])!==(b[1]>p[1]))&&(p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0]))yes=!yes}return yes}
function contains(g:Polygon|MultiPolygon,p:Position):boolean{return rings(g).some(poly=>poly.length>0&&insideRing(p,poly[0])&&!poly.slice(1).some(hole=>insideRing(p,hole)))}
function center(g:Polygon|MultiPolygon):Position{const poly=rings(g).sort((a,b)=>b[0].length-a[0].length)[0];const pts=poly?.[0]||[];if(!pts.length)return [35,39];let x=0,y=0;for(const p of pts){x+=p[0];y+=p[1]}return [x/pts.length,y/pts.length]}
function label(f:Feature){return f.properties.shapeName||f.properties.name||'Adsız yerleşim'}
// Geographically anchored symbolic vehicle; not presented as a road-network route.
const BURC:Position=[34.96,37.89],CAMARDI:Position=[34.99,37.84];
export default function TurkeyMap({game,onSelect}: {game:Game;onSelect:(city:string,district:string)=>void}){
 const [provinces,setProvinces]=useState<Collection|null>(null),[districts,setDistricts]=useState<Collection|null>(null);
 const [selected,setSelected]=useState<Feature|null>(null),[loading,setLoading]=useState(true),[error,setError]=useState('');
 const [zoom,setZoom]=useState(1),[offset,setOffset]=useState<Position>([0,0]);
 const [attempt,setAttempt]=useState(0);
 useEffect(()=>{let live=true;setLoading(true);setError('');Promise.all([getLevel('ADM1'),getLevel('ADM2')]).then(([p,d])=>{if(live){setProvinces(p);setDistricts(d);setLoading(false)}}).catch(e=>{if(live){setError(String(e?.message||e));setLoading(false)}});return()=>{live=false}},[attempt]);
 const matched=useMemo(()=>selected&&districts?districts.features.filter(f=>contains(selected.geometry,center(f.geometry))):[],[selected,districts]);
 const selectedName=selected?label(selected):'';
 const reset=()=>{setSelected(null);setZoom(1);setOffset([0,0])};
 const selectProvince=(f:Feature)=>{setSelected(f);setZoom(3.1);const [x,y]=project(center(f.geometry));setOffset([W/2-3.1*x,H/2-3.1*y]);onSelect(label(f),'')};
 const selectDistrict=(f:Feature)=>onSelect(selectedName,label(f));
 const busPoint=project([BURC[0]+(CAMARDI[0]-BURC[0])*(game.routes.find(r=>r.status==='active')?.elapsed||0)/90,BURC[1]+(CAMARDI[1]-BURC[1])*(game.routes.find(r=>r.status==='active')?.elapsed||0)/90]);
 return <div className="realmap">
  <div className="maptoolbar"><div><strong>Türkiye · gerçek idari sınırlar</strong><small>geoBoundaries / OpenStreetMap · kaynak atfı aşağıda</small></div><div className="mapbuttons"><button onClick={reset}>Türkiye</button><button onClick={()=>setZoom(z=>Math.min(9,z*1.5))}>＋</button><button onClick={()=>setZoom(z=>Math.max(1,z/1.5))}>−</button></div></div>
  {loading?<div className="mapstatus">Türkiye'nin il ve ilçe sınırları yükleniyor…</div>:error?<div className="mapstatus"><b>Harita verisi yüklenemedi.</b><p>{error}</p><p>İnternet bağlantısını ve veri sağlayıcısını kontrol et. Sahte harita gösterilmiyor.</p><button onClick={()=>setAttempt(v=>v+1)}><RefreshCw size={15}/> Yeniden dene</button></div>:<>
   <div className="mapviewport"><svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Türkiye gerçek il ve ilçe sınırları haritası" preserveAspectRatio="xMidYMid meet">
    <rect width={W} height={H} fill="#102b42"/>
    <g transform={`translate(${offset[0]} ${offset[1]}) scale(${zoom})`}>
     {provinces?.features.map((f,i)=><path key={i} d={path(f.geometry)} className={`province ${selected===f?'active':''}`} onClick={()=>selectProvince(f)}><title>{label(f)}</title></path>)}
     {selected&&matched.map((f,i)=><path key={i} d={path(f.geometry)} className="district" onClick={()=>selectDistrict(f)}><title>{label(f)}</title></path>)}
     {game.minibus&&<g transform={`translate(${busPoint[0]} ${busPoint[1]}) scale(${1/zoom})`}><circle r="12" fill="#e6b65f"/><path d="M-7 -4H7V5H-7Z M-5 5V8 M5 5V8" fill="none" stroke="#132437" strokeWidth="2"/></g>}
    </g>
   </svg><div className="mapcorner">{provinces?.features.length} il sınırı · {districts?.features.length} ilçe sınırı</div></div>
   <div className="mapselection"><MapPinned size={18}/><div><b>{selectedName||'Haritadan bir il seç'}</b><small>{selected?`${matched.length} ilçe sınırı · İlçeye dokunarak seçebilirsin`:'İl sınırına dokununca ilçeleri görünür'}</small></div>{selected&&<button onClick={reset}>Geri</button>}</div>
   {selected&&<div className="districtchips">{matched.map((f,i)=><button key={i} onClick={()=>selectDistrict(f)} className={game.district===label(f)?'chosen':''}>{label(f)}</button>)}</div>}
  </>}
  <div className="mapcredit"><span>Veri: <a href="https://www.geoboundaries.org/" target="_blank" rel="noreferrer">geoBoundaries</a> (gbOpen, CC BY 4.0); kaynak veriler için sağlayıcı koşullarını inceleyin.</span><span><BusFront size={13}/> Minibüs sembolü örnek koordinatlardadır; gerçek yol rotası henüz eklenmedi.</span></div>
 </div>
}
